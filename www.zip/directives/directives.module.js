/**
 * Created by tim on 4-1-15.
 */
(function () {
    'use strict';

    angular
        .module('kaatjeHelpt.directives', []);
})();